let data=JSON.parse(JSON.stringify(window.SITE_DATA));
const $=s=>document.querySelector(s);
function esc(v){return String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#039;"}[c]))}
function input(label,key,value){return `<label>${label}<input data-key="${key}" value="${esc(value)}"></label>`}
function render(){
 $("#orders").value=data.sale.orders;$("#pricing").value=data.sale.pricing;$("#services").value=data.sale.services;$("#discounts").value=data.sale.discounts;
 $("#clients").innerHTML=data.clients.map((c,i)=>`<div class="item">${input("Name",`c.${i}.name`,c.name)}${input("Description",`c.${i}.description`,c.description)}${input("Logo URL",`c.${i}.logo`,c.logo)}<button class="danger" onclick="removeClient(${i})">Remove</button></div>`).join("");
 const sections=[
  ["discord","Discord Development",["title","description","image"]],
  ["bots","Custom Bots",["title","logo","description","details","invite"]],
  ["branding","Branding",["type","title","image"]]
 ];
 $("#work").innerHTML=sections.map(([key,title,fields])=>`<h2>${title}</h2>${data.work[key].map((p,i)=>`<div class="item">${fields.map(f=>f==="type"?`<label>Type<select data-key="w.${key}.${i}.${f}"><option value="logo" ${p[f]==="logo"?"selected":""}>Logo</option><option value="banner" ${p[f]==="banner"?"selected":""}>Banner</option></select></label>`:input(f,`w.${key}.${i}.${f}`,p[f])).join("")}<button class="danger" onclick="removeWork('${key}',${i})">Remove</button></div>`).join("")}<button onclick="addWork('${key}')">+ Add ${title} project</button>`).join("");
}
function setByKey(k,v){const a=k.split(".");if(a[0]==="c") data.clients[a[1]][a[2]]=v;else data.work[a[1]][a[2]][a[3]]=v}
document.addEventListener("input",e=>{if(e.target.dataset.key)setByKey(e.target.dataset.key,e.target.value)});
$("#saveSale").onclick=()=>{data.sale={orders:Number($("#orders").value)||0,pricing:$("#pricing").value,services:$("#services").value,discounts:$("#discounts").value};save()};
$("#addClient").onclick=()=>{data.clients.push({name:"New Client",description:"",logo:""});render()};
window.removeClient=i=>{data.clients.splice(i,1);render()};window.removeWork=(k,i)=>{data.work[k].splice(i,1);render()};
window.addWork=k=>{data.work[k].push(k==="bots"?{title:"New Bot",logo:"",description:"",details:"",invite:""}:k==="branding"?{type:"logo",title:"New Branding Item",image:""}:{title:"New Discord Project",description:"",image:""});render()};
function save(){localStorage.setItem("lewcasiSiteData",JSON.stringify(data));alert("Saved in this browser.");}
$("#export").onclick=()=>{const text="window.SITE_DATA = "+JSON.stringify(data,null,2)+";";const a=document.createElement("a");a.href=URL.createObjectURL(new Blob([text],{type:"text/javascript"}));a.download="data.js";a.click()};
$("#import").onclick=()=>{try{const x=JSON.parse($("#importBox").value);data=x;save();render();alert("Imported.")}catch(e){alert("Invalid JSON.")}};
const stored=localStorage.getItem("lewcasiSiteData");if(stored)try{data=JSON.parse(stored)}catch(e){}render();