/* Public website settings. Do not put passwords or private API keys here. */
window.SITE_CONFIG = {
  contactUrl: "https://discord.gg/jGpBbpYuY4",
  visitorCounterUrl: "https://api.counterapi.dev/v1/lewcasi-site/views/up",
  useSupabase: false,
  supabaseUrl: "",
  supabaseAnonKey: ""
};