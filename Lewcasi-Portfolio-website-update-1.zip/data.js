window.SITE_DATA = {
  clients: [
    {name:"Clearwater Roleplay", description:"Branding Order", logo:""}
  ],
  sale: {
    orders: 2,
    pricing: "View my Comms Server for pricing.",
    services: "Discord Development, Custom Bots, Branding",
    discounts: "Free Branding and Discord Development"
  },
  work: {
    discord: [
      {title:"Example Discord Project", description:"Replace this with your Discord development project.", image:""}
    ],
    bots: [
      {title:"Lewcasi's Darts Stats Managet", logo:"", description:"Click a bot to view its information.", details:"Add the bot's features, purpose and other information here.", invite:""}
    ],
    branding: [
      {type:"logo", title:"Example Logo", image:""},
      {type:"banner", title:"Example Banner", image:""}
    ]
  }
};