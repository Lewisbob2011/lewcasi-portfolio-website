# Lewcasi Website

A mobile-first static portfolio website with:
- Clients section
- Sale Information: orders completed, pricing, available services and discounts
- Past Work categories: Discord Development, Custom Bots and Branding
- Custom Bots modal with bot name, logo, details and optional Invite button
- Branding limited to Logo and Banner
- Public visitor counter
- Mobile navigation
- Admin panel
- No Discord link field for clients

## Files

- `index.html` — public website
- `style.css` — design
- `app.js` — website behaviour
- `config.js` — public settings
- `data.js` — starter content
- `admin/index.html` — admin panel
- `admin/admin.js` / `admin/admin.css` — admin panel files

## Important admin note

The included admin panel is deliberately safe for a static site: it stores edits in the browser's localStorage. That means it is NOT a secure multi-user CMS and edits made on one phone/browser do not automatically change the public site for everyone.

If you want a real online admin panel where you log in and changes immediately appear for every visitor, connect the site to Supabase (free tier) or another database. Do not put a service-role/private key in `config.js`.

## Static hosting

Recommended: Cloudflare Pages. It supports static HTML sites and GitHub/GitLab deployment.

Alternative: GitHub Pages, Netlify or Vercel.

For a simple static site:
1. Put the whole project into a GitHub repository.
2. Connect the repository to Cloudflare Pages.
3. Set the build command to blank.
4. Set the output/root directory to `/`.
5. Deploy.

## Spck Editor

Open/create a project in Spck Editor and copy these files into the project. `index.html` is the main launch file. Spck supports mobile-first editing and Git integration.

## Visitor counter

The default `config.js` uses a public counter endpoint. If you want a more controlled analytics/counter setup, replace `visitorCounterUrl` with your chosen service.

## Changing contact

Edit `contactUrl` in `config.js`.

## Supabase

If you want the admin panel to be a genuine shared CMS, the next version should use Supabase Auth + database/storage. The public anonymous key can be exposed in a frontend application, but the database must have proper Row Level Security policies. Never expose a Supabase service-role key in the website.
