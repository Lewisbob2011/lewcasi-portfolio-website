const D = window.SITE_DATA || { clients: [], sale: { orders: 0, pricing: "Contact for pricing", services: "Discord Development, Custom Bots, Branding", discounts: "No active discounts" }, work: { discord: [], bots: [], branding: [] } };
const $ = s => document.querySelector(s);
document.getElementById("year").textContent = new Date().getFullYear();

const header = document.querySelector(".site-header");
const menuToggle = document.querySelector(".menu-toggle");

if (!menuToggle || !header) throw new Error("Navigation elements are missing from index.html");

menuToggle.addEventListener("click", () => {
  header.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", header.classList.contains("open") ? "true" : "false");
});

document.querySelectorAll("nav a").forEach(link => {
  link.addEventListener("click", event => {
    const targetId = link.getAttribute("href");
    if (!targetId || !targetId.startsWith("#")) return;

    const target = document.querySelector(targetId);
    if (!target) return;

    event.preventDefault();
    header.classList.remove("open");
    menuToggle.setAttribute("aria-expanded", "false");

    const headerHeight = document.querySelector(".site-header").offsetHeight;
    const targetTop = target.getBoundingClientRect().top + window.scrollY - headerHeight - 10;

    window.scrollTo({
      top: Math.max(0, targetTop),
      behavior: "smooth"
    });

    history.replaceState(null, "", targetId);
  });
});

function esc(v){return String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#039;"}[c]))}
function imgOrBlank(src, cls=""){ return src ? `<img class="${cls}" src="${esc(src)}" alt="">` : "" }

function render(){
  $("#clientsGrid").innerHTML=D.clients.map(c=>`<article class="client">${imgOrBlank(c.logo,"client-logo")}<h3>${esc(c.name)}</h3><p class="muted">${esc(c.description)}</p></article>`).join("");
  $("#orders").textContent=D.sale.orders;
  $("#pricing").textContent=D.sale.pricing;
  $("#services").textContent=D.sale.services;
  $("#discounts").textContent=D.sale.discounts;
}
render();

document.querySelectorAll(".category").forEach(btn=>btn.addEventListener("click",()=>{
  const cat=btn.dataset.category;
  $("#projectArea").classList.remove("hidden");
  $("#projectTitle").textContent={discord:"Discord Development",bots:"Custom Bots",branding:"Branding"}[cat];
  const items=D.work[cat]||[];
  $("#projectsGrid").innerHTML=items.map((p,i)=>{
    if(cat==="bots") return `<article class="project bot" data-bot="${i}">${imgOrBlank(p.logo,"client-logo")}<h3>${esc(p.title)}</h3><p class="muted">${esc(p.description)}</p></article>`;
    return `<article class="project">${imgOrBlank(p.image)}<h3>${esc(p.title)}</h3><p class="muted">${esc(p.description||"")}</p></article>`;
  }).join("") || `<p class="muted">No projects have been added yet.</p>`;
  document.querySelectorAll(".project.bot").forEach(el=>el.addEventListener("click",()=>{
    const p=D.work.bots[Number(el.dataset.bot)];
    const m=document.createElement("div");m.className="modal";m.innerHTML=`<div class="modal-card"><button class="modal-close">×</button>${imgOrBlank(p.logo,"client-logo")}<h2>${esc(p.title)}</h2><p class="muted">${esc(p.details||"")}</p>${p.invite?`<a class="button primary" href="${esc(p.invite)}" target="_blank" rel="noopener">Invite</a>`:""}</div>`;
    document.body.appendChild(m);m.querySelector(".modal-close").onclick=()=>m.remove();m.onclick=e=>{if(e.target===m)m.remove()};
  }));
  $("#projectArea").scrollIntoView({behavior:"smooth",block:"start"});
}));
$("#backToCategories").addEventListener("click",()=>$("#projectArea").classList.add("hidden"));
$("#contactButton").href=window.SITE_CONFIG.contactUrl;
$("#contactButton").target="_blank";
$("#contactButton").rel="noopener noreferrer";

async function visitorCount(){
  try{
    const url=window.SITE_CONFIG.visitorCounterUrl;
    if(!url){$("#visitorCount").textContent="";return}
    const r=await fetch(url,{cache:"no-store"}); const j=await r.json();
    const n=j.count ?? j.value ?? j.data?.count;
    if(n!=null) $("#visitorCount").textContent=Number(n).toLocaleString();
  }catch(e){ $("#visitorCount").textContent=""; }
}
visitorCount();